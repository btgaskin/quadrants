"""Prepare a sanitized, separate receipt for the completed layout control."""

import hashlib
import json
from pathlib import Path
from statistics import median

BASE = Path(__file__).resolve().parent
PACKET = BASE.parent
ROOT = BASE.parents[3]
(PACKET / "attachments").mkdir(parents=True, exist_ok=True)
names = [f"n512-b{batch}-d16-s{seed}" for batch in (32, 1) for seed in (7, 19, 41)]
cases = []
groups = []
for name in names:
    record = json.loads((BASE / (name + ".json")).read_text())
    assert record["passed"]
    for scope in record["timing"].values():
        for path, values in scope["samples_seconds"].items():
            assert len(values) == 6 and all(value > 0 for value in values)
            assert median(values) == scope["medians_seconds"][path]
            for position in range(3):
                assert sum(order[position] == path for order in scope["order_by_block"]) == 2
            assert len(scope["checks"][path]) == 8
            assert all(check["passed"] and check["byte_equal"] for block in scope["checks"][path] for check in block["outputs"].values())
    public = {key: value for key, value in record.items() if key not in ("environment_before", "environment_after")}
    public["environment_summary"] = {
        phase: dict(utc=record[phase]["utc"],
                    ac_power="AC Power" in record[phase]["power"]["stdout"],
                    thermal_status_available=not any("Error" in record[phase]["thermal"][key] for key in ("stdout", "stderr")))
        for phase in ("environment_before", "environment_after")
    }
    public["case"] = name
    cases.append(public)
for batch in (1, 32):
    selected = [case for case in cases if case["config"]["batch"] == batch]
    assert {case["config"]["seed"] for case in selected} == {7, 19, 41}
    group = dict(n=512, batch=batch, degree=16, scopes={})
    for scope in ("resident", "workflow"):
        times = {path: [case["timing"][scope]["medians_seconds"][path] for case in selected]
                 for path in ("source_major", "receiver_major", "csr")}
        ratios = {key: [case["timing"][scope]["ratios_of_medians"][key] for case in selected]
                  for key in ("receiver_over_source", "source_over_csr", "receiver_over_csr")}
        group["scopes"][scope] = dict(
            times={path: dict(median_seconds=median(values), seed_min_seconds=min(values), seed_max_seconds=max(values))
                   for path, values in times.items()},
            ratios={key: dict(median=median(values), seed_min=min(values), seed_max=max(values)) for key, values in ratios.items()},
        )
    groups.append(group)
sources = {name: hashlib.sha256((BASE / name).read_bytes()).hexdigest()
           for name in ("source-major-demo.py", "receiver-major-demo.py", "run-case.py", "run-sweep.py", "variant-manifest.json")}
receipt = dict(
    purpose="Secondary dense-layout control for the K=1 Quadrants ESN benchmark",
    source_identity=sources, native_sha256=cases[0]["native_sha256"], build_commit=cases[0]["build_commit"],
    benchmark_scope="Authored scalar K=1 Quadrants row-parallel kernels on Metal; two dense layouts and CSR",
    layout_mechanism="At fixed source, adjacent receiver threads read adjacent f32 weights in source-major storage; receiver-major spacing is N*4 bytes. This is a locality hypothesis, without hardware-counter attribution.",
    changed_code="Only dense upload layout, dense weight indexing and input-integrity expected layout differ",
    aggregation="Median of three seed medians for elapsed time; median of three per-seed ratios of medians for ratios",
    protocol="Six recorded complete three-path permutations per clock/seed after two warmup blocks; every path occupies each position twice",
    relation_to_primary_receipt="Separate current-build confirmation; original 39-case/5-block measurements and headline values remain unchanged",
    background_condition="Interactive desktop; private before/after process/memory/power snapshots retained with execution reports. Close one-trial layout differences are descriptive.",
    reproduction="Run the existing ESN command for B=1/32 and seeds 7/19/41 to save frozen cases; run the retained run-case.py with corresponding --batch and --seed using the exact two demo snapshots and current build",
    numerical_checks="All three paths pass original float64 gates and byte-match saved qualified CSR; every actual warmup/timed output byte-matches the saved qualified result; input integrity checked before/after clocks",
    recorded_timed_executions=len(cases) * 2 * 6 * 3,
    warmup_executions=len(cases) * 2 * 2 * 3,
    groups=groups, cases=cases,
)
(PACKET / "attachments/layout-control.json").write_text(json.dumps(receipt, indent=2, allow_nan=False) + "\n")
lines = ["# Current-build dense-layout control", "", "All six cases qualified and all actual warmed/timed outputs were byte-identical to the archived CSR result. Times and ratios use three-seed summaries; this six-permutation protocol remains separate from the original five-block performance sweep.", "", "| Trials / clock | Source-major dense (ms) | Receiver-major dense (ms) | CSR (ms) | Receiver/source time ratio |", "|---|---:|---:|---:|---:|"]
for group in groups:
    for clock, data in group["scopes"].items():
        t = data["times"]
        lines.append(f"| {group['batch']} / {clock} | {1000*t['source_major']['median_seconds']:.3f} | {1000*t['receiver_major']['median_seconds']:.3f} | {1000*t['csr']['median_seconds']:.3f} | {data['ratios']['receiver_over_source']['median']:.3f} |")
lines.extend(["", "Source-major favors adjacent weight addresses across receiver threads; receiver-major favors contiguous inner-loop access within one thread. The observed layout comparison does not attribute a measured hardware-counter bottleneck. Both are authored scalar Quadrants implementations.", "", "Full raw samples, equality/oracle checks, source/native identities and sanitized environment summaries are in `../attachments/layout-control.json`. Private execution snapshots remain in the local case reports. No data were published."])
(BASE / "results.md").write_text("\n".join(lines) + "\n")
print(json.dumps(groups, indent=2))
