# Supplemental dense-layout control

This local experiment compares the authored source-major dense, receiver-major dense and CSR implementations on the same frozen Quadrants ESN fixtures. It reuses the proposed demo's device code, qualifies every path against the saved float64 reference and qualified CSR arrays, and checks every warmed/timed output after its clock. The receiver variant changes only dense upload layout, dense indexing and the corresponding input-integrity expectation. `variant-manifest.json` describes those exact substitutions.

Cases are N512/degree16, B1/B32, seeds 7/19/41, with washout 100, training 1000, held-out 300 and autonomous 128. Every scope/seed has two warmups and all six recorded permutations of the three paths. This balances every path in each execution-order position. The primary 39-case sweep uses a different five-pair protocol and remains separate.

The original current-build fixtures are retained in `../performance/`. A reproduction on a checkout with NumPy and Quadrants installed can regenerate one fixture and run its three-path comparison:

```bash
mkdir -p outputs/csr-spmm/pr-draft/performance
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
python misc/demos/csr_spmm_esn.py --arch metal --n 512 --batch 32 --degree 16 \
  --washout 100 --train 1000 --test 300 --free 128 --seed 7 \
  --save outputs/csr-spmm/pr-draft/performance/n512-b32-d16-s7.npz
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
python outputs/csr-spmm/pr-draft/layout-control/run-case.py --batch 32 --seed 7
```

The source ZIP places these helpers under the same `outputs/` path when extracted at the repository root. Repeat with B1/B32 and seeds 7/19/41 before running `prepare-results.py`. The runner verifies the checkout Python path, identical demo snapshots and the native identity of the regenerated fixture. Initial fixture generation, allocation, compilation and qualification are outside its clocks. The sequential `run-sweep.py` is the exact local driver used here, with this checkout's editable-build/cache environment.

`results.md` summarizes the completed cases. `../attachments/layout-control.json` is the sanitized shareable receipt; case JSON/logs and the receiver-qualified NPZs retain full local evidence. Process/memory/power snapshots remain local.

The archive README and scheduling docstring have documentation-only edits. Executable statements and numerical records are unchanged; receipt source hashes identify the original measured versions.
