"""Recheck both dense layouts and CSR against a frozen current-build ESN case."""

import argparse
import datetime
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import platform
import subprocess
import sys
from time import perf_counter

import numpy as np

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def array_identity(value):
    value = np.ascontiguousarray(value)
    return dict(dtype=str(value.dtype), shape=list(value.shape), sha256=hashlib.sha256(memoryview(value).cast("B")).hexdigest())


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def snapshot():
    result = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
    for key, command in {
        "cpu": ["ps", "-Ao", "pid,pcpu,rss,comm", "-r"],
        "memory": ["vm_stat"],
        "power": ["pmset", "-g", "batt"],
        "thermal": ["pmset", "-g", "therm"],
    }.items():
        process = subprocess.run(command, capture_output=True, text=True)
        result[key] = dict(exit=process.returncode, stdout=process.stdout, stderr=process.stderr)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=int, choices=(1, 32), required=True)
    parser.add_argument("--seed", type=int, choices=(7, 19, 41), required=True)
    args = parser.parse_args()
    name = f"n512-b{args.batch}-d16-s{args.seed}"
    archive = ROOT / "outputs/csr-spmm/pr-draft/performance" / (name + ".npz")
    previous = json.loads(archive.with_suffix(".json").read_text())
    source = module("layout_source", BASE / "source-major-demo.py")
    receiver = module("layout_receiver", BASE / "receiver-major-demo.py")
    assert sha(ROOT / "misc/demos/csr_spmm_esn.py") == sha(BASE / "source-major-demo.py")
    assert previous["metadata"]["demo_sha256"] == sha(BASE / "source-major-demo.py")
    c = source.Config(**previous["metadata"]["config"])
    c.validate()
    with np.load(archive, allow_pickle=False) as saved:
        keys = ("row_ptr", "col_idx", "values", "dense", "win", "bias", "probe", "inputs", "targets")
        arrays = {key: saved[key] for key in keys}
        expected = {key: saved[f"csr_{key}"] for key in ("linear", "states", "predictions", "free")}
        expected["readout"] = saved[f"csr_readout_{c.train}"]
        expected.update({f"own_{key}": saved[f"csr_own_{c.train}_{key}"] for key in ("predictions", "free")})
        shared = saved["shared_readout"]
        reference = {key: saved[f"reference_{key}"] for key in ("linear", "states", "predictions", "free")}
    fixture_digest = hashlib.sha256(b"".join(arrays[key].tobytes() for key in sorted(arrays))).hexdigest()
    assert fixture_digest == previous["metadata"]["fixture_sha256"]
    qd = source.qd
    qd.init(arch=qd.metal, enable_fallback=False, default_fp=qd.f32, fast_math=False)
    native = Path(qd._lib.core.__file__).resolve()
    assert sha(native) == previous["metadata"]["native_sha256"]
    assert qd._lib.core.get_commit_hash() == previous["metadata"]["build_commit"]
    assert Path(qd.__file__).resolve().is_relative_to(ROOT / "python")
    report = dict(
        config=previous["metadata"]["config"],
        platform=platform.platform(), arch="metal", fast_math=False, default_fp="f32",
        native_sha256=sha(native), build_commit=qd._lib.core.get_commit_hash(),
        source_major_sha256=sha(BASE / "source-major-demo.py"), receiver_major_sha256=sha(BASE / "receiver-major-demo.py"),
        runner_sha256=sha(Path(__file__)), frozen_npz=archive.name, frozen_npz_sha256=sha(archive),
        fixture_sha256=fixture_digest, input_arrays={key: array_identity(value) for key, value in arrays.items()},
        expected_arrays={key: array_identity(value) for key, value in expected.items()},
        oracle_arrays={key: array_identity(value) for key, value in reference.items()},
        timing_policy="Six recorded complete three-path permutations per scope/seed after two warmups; no pooling with original sweep",
        boundaries=dict(resident="256 updates, zero reset/download outside clock, no history writes",
                        workflow="Reset, all teacher states/download, own float64 fit/upload, driven/free outputs/download"),
        synchronization="Every 32 updates and at scope boundaries; validation outside clocks",
        environment_before=snapshot(), qualification={}, timing={},
    )
    runtimes = {}
    for path_name, helper, dense in (("source_major", source, True), ("receiver_major", receiver, True), ("csr", source, False)):
        runtime = {}
        result, evaluate, _ = helper.device(c, arrays, dense, runtime=runtime)
        result.update(evaluate(shared))
        result["readout"] = source.fit(c, arrays, result["states"], c.train)
        result.update({f"own_{key}": value for key, value in evaluate(result["readout"]).items()})
        equivalence = {key: source.compare(value, expected[key], 3e-5, 3e-4) for key, value in result.items()}
        assert all(check["passed"] and check["byte_equal"] for check in equivalence.values())
        gates = {key: source.compare(result[key], reference[key], atol, rtol)
                 for key, atol, rtol in (("linear", 3e-5, 3e-4), ("states", 3e-5, 3e-4), ("predictions", 1e-4, 1e-3))}
        gates["free_first16"] = source.compare(result["free"][:16], reference["free"][:16], 3e-4, 3e-3)
        assert all(check["passed"] for check in gates.values())
        report["qualification"][path_name] = dict(equivalence_to_saved_csr=equivalence, float64_checks=gates,
                                                    full_free_max_abs=float(np.max(np.abs(result["free"] - reference["free"]))),
                                                    array_hashes={key: array_identity(value) for key, value in result.items()})
        if path_name == "receiver_major":
            np.savez_compressed(BASE / (name + "-receiver-qualified.npz"), **result)
        runtimes[path_name] = runtime
        del result
        print(f"{name}: qualified {path_name}", flush=True)
    report["integrity_before"] = {name: runtime["check_inputs"]() for name, runtime in runtimes.items()}
    names = tuple(runtimes)
    permutations = list(itertools.permutations(names))
    rotation = (7, 19, 41).index(c.seed) * 2
    orders = permutations[rotation:] + permutations[:rotation]
    for scope in ("resident", "workflow"):
        samples = {name: [] for name in names}
        checks = {name: [] for name in names}
        for block, order in enumerate([orders[0], tuple(reversed(orders[0])), *orders]):
            recorded = block >= 2
            for path_name in order:
                runtime = runtimes[path_name]
                if scope == "resident":
                    runtime["reset"]()
                qd.sync()
                started = perf_counter()
                output = runtime[scope]()
                qd.sync()
                seconds = perf_counter() - started
                assert np.isfinite(seconds) and seconds > 0
                if scope == "resident":
                    actual = dict(states=runtime["read_resident"](output))
                    qualified = dict(states=expected["states"][255])
                else:
                    actual = output
                    qualified = dict(states=expected["states"], readout=expected["readout"],
                                     predictions=expected["own_predictions"], free=expected["own_free"])
                checked = {key: source.compare(value, qualified[key], 3e-5, 3e-4) for key, value in actual.items()}
                assert all(check["passed"] and check["byte_equal"] for check in checked.values())
                checks[path_name].append(dict(phase="timed" if recorded else "warmup", block=block - 2 if recorded else block,
                                              outputs=checked, output_hashes={key: array_identity(value) for key, value in actual.items()}))
                if recorded:
                    samples[path_name].append(seconds)
                del actual, output
            print(f"{name}: {scope} {'timed' if recorded else 'warmup'} {block - 2 if recorded else block}", flush=True)
        medians = {name: float(np.median(values)) for name, values in samples.items()}
        report["timing"][scope] = dict(samples_seconds=samples, medians_seconds=medians, order_by_block=orders,
                                       checks=checks, ratios_of_medians={
                                           "receiver_over_source": medians["receiver_major"] / medians["source_major"],
                                           "source_over_csr": medians["source_major"] / medians["csr"],
                                           "receiver_over_csr": medians["receiver_major"] / medians["csr"],
                                       })
    report["integrity_after"] = {name: runtime["check_inputs"]() for name, runtime in runtimes.items()}
    assert all(ok for stage in ("integrity_before", "integrity_after") for path in report[stage].values() for ok in path.values())
    report["environment_after"] = snapshot()
    report["passed"] = True
    (BASE / (name + ".json")).write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({name: value["ratios_of_medians"] for name, value in report["timing"].items()}), flush=True)


if __name__ == "__main__":
    main()
