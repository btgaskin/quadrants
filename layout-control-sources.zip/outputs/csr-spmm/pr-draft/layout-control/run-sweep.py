"""Run the current-build dense-layout control sequentially."""

import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
env = dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1",
           SKBUILD_EDITABLE_SKIP=str(ROOT / "build/cp310-cp310-macosx_26_0_arm64"),
           QD_OFFLINE_CACHE="1", QD_OFFLINE_CACHE_FILE_PATH=str(BASE / "kernel-cache"),
           QD_OFFLINE_CACHE_CLEANING_POLICY="never")
(BASE / "kernel-cache").mkdir(exist_ok=True)
inventory = []
for batch in (32, 1):
    for seed in (7, 19, 41):
        name = f"n512-b{batch}-d16-s{seed}"
        command = [str(ROOT / ".venv/bin/python"), str(BASE / "run-case.py"), "--batch", str(batch), "--seed", str(seed)]
        started = time.perf_counter()
        with (BASE / (name + ".log")).open("w") as log:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        inventory.append(dict(name=name, command=command, exit=result.returncode, process_seconds=time.perf_counter() - started))
        (BASE / "inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
        if result.returncode:
            raise SystemExit(f"Failed {name}; full log retained")
        report = json.loads((BASE / (name + ".json")).read_text())
        assert report["passed"]
        print(json.dumps({"completed": len(inventory), "case": name,
                          "ratios": {scope: record["ratios_of_medians"] for scope, record in report["timing"].items()}}), flush=True)
